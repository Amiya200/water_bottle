#ifndef APP_LOGIC_H
#define APP_LOGIC_H

#include "stm32f0xx_hal.h"
#include "ble_protocol.h"
#include <stdint.h>

/* ─── Sensor poll intervals ─────────────────────────────────── */
#define APP_WEIGHT_POLL_MS       200U
#define APP_TDS_POLL_MS         5000U
#define APP_TEMP_POLL_MS        5000U
#define APP_BATTERY_POLL_MS    10000U
#define APP_BLE_STATE_POLL_MS   1000U
#define APP_REMINDER_CHECK_MS  60000U
#define APP_BUTTON_POLL_MS        50U

/* ─── Physical button ───────────────────────────────────────── */
#define BTN_LONG_PRESS_MS       3000U
#define BTN_VLONG_PRESS_MS     10000U
#define BTN_RESET_CONFIRM_MS    5000U

/* ─── Drink detection ───────────────────────────────────────── */
#define DRINK_MIN_VOLUME_ML     10U
#define DRINK_SETTLE_MS         3000U
#define DRINK_WEIGHT_STABLE_MS   500U
#define DRINK_STABLE_BAND_G        3U

/* ─── Hydration score thresholds ────────────────────────────── */
#define HYDRATION_SCORE_HIGH    80
#define HYDRATION_SCORE_MID     50

/*
 * RAM-optimised app API
 * ---------------------
 * The old public app-context workflow was removed.  app_logic.c now
 * owns only the state it actually uses as file-scope static variables.  main.c
 * calls App_Init() once and App_Run() forever; interrupts are forwarded through
 * the small App_*ISR wrappers below.
 */
void App_Init(ADC_HandleTypeDef  *hadc,
              I2C_HandleTypeDef  *hi2c,
              UART_HandleTypeDef *huart,
              TIM_HandleTypeDef  *htim_ws,
              TIM_HandleTypeDef  *htim_buz);

void App_Run(void);

/* Interrupt forwarders used by main.c callbacks. */
void App_BMA_MotionISR(void);
void App_RTC_TickISR(void);
void App_BLE_RxISR(void);

/* Sensor/task entry points kept public for test builds. */
void App_TaskWeight(void);
void App_TaskTDS(void);
void App_TaskTemp(void);
void App_TaskBattery(void);
void App_TaskBLE(void);
void App_ServiceBLE(void);
void App_TaskReminder(void);
void App_TaskButton(void);
void App_TaskDailyRollup(void);

void    App_CheckDrinkEvent(void);
void    App_RecordDrinkEvent(uint16_t volume_ml);
uint8_t App_CalcHydrationScore(void);
void    App_ResetDailyConsumed(void);

void App_HandleBLECommand(const BLE_Packet_t *pkt);
void App_HandleStringCommand(char *line);

void App_Cmd_Timestamp(const BLE_Packet_t *pkt);
void App_Cmd_InputData(const BLE_Packet_t *pkt);
void App_Cmd_Calibration(const BLE_Packet_t *pkt);
void App_Cmd_LampMode(const BLE_Packet_t *pkt);
void App_Cmd_SoftReset(void);
void App_Cmd_FactoryReset(void);
void App_Cmd_HistoricalAggregates(void);
void App_Cmd_RegisterDevice(const BLE_Packet_t *pkt);
void App_Cmd_UnpairDevice(void);
void App_Cmd_SensorLogs(void);
void App_Cmd_SyncAck(const BLE_Packet_t *pkt);
void App_Cmd_DeviceStatus(void);
void App_Cmd_GetConfig(void);
void App_Cmd_GetErrors(void);
void App_Cmd_Ping(void);

void App_SendACK(uint8_t cmd_id, uint8_t success, uint8_t err_code);

#endif /* APP_LOGIC_H */
